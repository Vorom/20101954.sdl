#pragma once

enum State
{
	Menu,
	Play,
	GameOver,
	Pause
};